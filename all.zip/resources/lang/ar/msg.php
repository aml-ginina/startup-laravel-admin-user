<?php

return array (
  'app_name' => 'لارافيل',
);
