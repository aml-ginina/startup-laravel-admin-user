<?php

return array (
  'action' => 'Action',
  'add_new' => 'Add New',
  'are_you_sure' => 'Are you sure?',
  'back' => 'Back',
  'cancel' => 'Cancel',
  'create' => 'Create',
  'created_at' => 'Created At',
  'deleted_at' => 'Deleted At',
  'detail' => 'Detail',
  'edit' => 'Edit',
  'id' => 'Id',
  'reply' => 'Reply',
  'save' => 'Save',
  'show' => 'Show',
  'updated_at' => 'Updated At',
);
