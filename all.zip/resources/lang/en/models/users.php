<?php

return array (
  'singular' => 'User',
  'plural' => 'Users',
  'fields' => [
    'id' => 'Id',
    'name' => 'Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'password' => 'Password',
    'image' => 'Image',
    'notes' => 'Notes',
    'block' => 'Block',
    'block_notes' => 'Block Notes',
    'email_verified_at' => 'Email Verified At',
    'remember_token' => 'Remember Token',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ],
);
