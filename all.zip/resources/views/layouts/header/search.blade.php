<!-- ============================================================== -->
<!-- Search -->
<!-- ============================================================== -->
<li class="nav-item">
    <form class="app-search d-none d-md-block d-lg-block">
        <input type="text" class="form-control" placeholder="@lang('msg.search_and_enter')">
    </form>
</li>