<?php $__env->startSection('title', __('crud.edit') . ' ' . __('models/providers.singular')); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.providers.index')); ?>"><?php echo app('translator')->get('models/providers.plural'); ?></a></li>
<li class="breadcrumb-item active"><?php echo app('translator')->get('crud.edit'); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php echo Form::model($provider, ['route' => ['admin.providers.update', $provider->id], 'method' => 'patch', 'files' => true]); ?>

                        <?php echo $__env->make('admin.providers.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/providers/edit.blade.php ENDPATH**/ ?>