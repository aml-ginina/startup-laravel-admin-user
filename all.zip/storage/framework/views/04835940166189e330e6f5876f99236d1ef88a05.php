<?php $__env->startSection('title', __('models/providers.plural')); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active"><?php echo app('translator')->get('models/providers.plural'); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-buttons'); ?>
<a href="<?php echo e(route('admin.providers.create')); ?>" class="btn btn-info d-none d-lg-block m-l-15"><i class="fa fa-plus-circle"></i> <?php echo app('translator')->get('crud.add_new'); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card col-sm-12">
        <div class="card-body p-0">
            <?php echo $__env->make('admin.providers.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/providers/index.blade.php ENDPATH**/ ?>