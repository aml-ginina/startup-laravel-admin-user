

<?php $__env->startSection('title', __('msg.profile')); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active"><?php echo app('translator')->get('msg.profile'); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Column -->
    <div class="col-lg-4 col-xlg-3 col-md-5">
        <div class="card">
            <div class="card-body">
                <center class="m-t-30"> 
                    
                    <h4 class="card-title m-t-10"><?php echo e($provider->name); ?></h4>
                    <h6 class="card-subtitle"><?php echo app('translator')->get('msg.app_name'); ?> <?php echo app('translator')->get('models/providers.singular'); ?></h6>
                    <div class="row text-center justify-content-md-center">
                        <div class="col-4"><a href="javascript:void(0)" class="link"><i class="icon-people"></i> <font class="font-medium">254</font></a></div>
                        <div class="col-4"><a href="javascript:void(0)" class="link"><i class="icon-picture"></i> <font class="font-medium">54</font></a></div>
                    </div>
                </center>
            </div>
            <div>
                <hr> </div>
            <div class="card-body"> 
                <small class="text-muted"> <?php echo app('translator')->get('msg.email'); ?> </small>
                <h6><?php echo e($provider->email); ?></h6> 
                <small class="text-muted p-t-30 db"><?php echo app('translator')->get('msg.active'); ?></small>
                <h6 class="mb-3"><?php echo $provider->active_span; ?></h6> 
                <button class="btn btn-circle btn-secondary"><i class="fab fa-facebook-f"></i></button>
                <button class="btn btn-circle btn-secondary"><i class="fab fa-twitter"></i></button>
                <button class="btn btn-circle btn-secondary"><i class="fab fa-youtube"></i></button>
            </div>
        </div>
    </div>
    <!-- Column -->
    <!-- Column -->
    <div class="col-lg-8 col-xlg-9 col-md-7">
        <div class="card">
            <!-- Nav tabs -->
            <ul class="nav nav-tabs profile-tab" role="tablist">
                <li class="nav-item"> <a class="nav-link <?php echo e(!isset($active) || is_null($active) || $active == 'profile' ? 'active' : ''); ?>" data-toggle="tab" href="#profile" role="tab"><?php echo app('translator')->get('msg.profile'); ?></a> </li>
                <li class="nav-item"> <a class="nav-link <?php echo e($active == 'settings' ? 'active' : ''); ?>" data-toggle="tab" href="#settings" role="tab"><?php echo app('translator')->get('msg.settings'); ?></a> </li>
                <li class="nav-item"> <a class="nav-link <?php echo e($active == 'password' ? 'active' : ''); ?>" data-toggle="tab" href="#password" role="tab"><?php echo app('translator')->get('msg.password'); ?></a> </li>
            </ul>
            <!-- Tab panes -->
            <div class="tab-content">
                <!--Profile tab-->
                <?php echo $__env->make('provider.profile.profile_tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <!-- Settings tab -->
                <?php echo $__env->make('provider.profile.settings_tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <!-- Password tab -->
                <?php echo $__env->make('provider.profile.password_tab', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    <!-- Column -->
</div>
<!-- Row -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('provider.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/provider/profile/index.blade.php ENDPATH**/ ?>