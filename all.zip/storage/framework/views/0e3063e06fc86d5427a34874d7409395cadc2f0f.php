<?php $__env->startSection('title', __('msg.translation')); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active"><?php echo app('translator')->get('msg.translation'); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- Info box -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- Column -->
        <div class="col-md-12">
            <div class="card">
                <div class="card-body p-0">
                    <iframe src="<?php echo e(url('/admin/translations')); ?>"></iframe>
                </div>
            </div>
        </div>
        <!-- Column -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page_css'); ?> 
<style>
    iframe {
        width: 100%;
        height: calc(100vh - 20em);
        border: none;
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/translation.blade.php ENDPATH**/ ?>