<!-- Name Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('name', __('models/admins.fields.name').':'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Email Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('email', __('models/admins.fields.email').':'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control' . ($errors->first('email') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Password Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('password', __('models/admins.fields.password').':'); ?>

    <?php echo Form::password('password', ['class' => 'form-control' . ($errors->first('password') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Active Field -->
<div class="form-group col-sm-12">
    <div class="custom-control custom-checkbox mr-sm-2 mb-3">
        <?php echo Form::hidden('active', 0, ['class' => 'form-check-input']); ?>

        <?php echo Form::checkbox('active', '1', null, ['class' => 'custom-control-input', 'id' => 'active']); ?>

        <?php echo Form::label('active', __('models/admins.fields.active'), ['class' => 'custom-control-label']); ?>

    </div>
    <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<button type="submit" class="btn btn-primary"><?php echo app('translator')->get('crud.save'); ?></button>
<a href="<?php echo e(route('admin.admins.index')); ?>" class="btn btn-dark"><?php echo app('translator')->get('crud.cancel'); ?></a><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/admins/fields.blade.php ENDPATH**/ ?>