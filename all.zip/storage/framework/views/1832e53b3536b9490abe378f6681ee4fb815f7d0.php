<!-- Name Field -->
<tr>
    <td><?php echo app('translator')->get('models/users.fields.name'); ?></td>
    <td><?php echo e($user->name); ?></td>
</tr>

<!-- Email Field -->
<tr>
    <td><?php echo app('translator')->get('models/users.fields.email'); ?></td>
    <td><?php echo e($user->email); ?></td>
</tr>

<!-- Phone Field -->
<tr>
    <td><?php echo app('translator')->get('models/users.fields.phone'); ?></td>
    <td><?php echo e($user->phone); ?></td>
</tr>

<!-- Image Field -->
<tr>
    <td><?php echo app('translator')->get('models/users.fields.image'); ?></td>
    <td><img src="<?php echo e(asset('images/users/'.$user->image)); ?>" alt="" /></td>
</tr>

<!-- Notes Field -->
<tr>
    <td><?php echo app('translator')->get('models/users.fields.notes'); ?></td>
    <td><?php echo e($user->notes); ?></td>
</tr>

<!-- Block Field -->
<tr>
    <td><?php echo app('translator')->get('models/users.fields.block'); ?></td>
    <td><?php echo $user->block_span; ?></td>
</tr>

<?php if($user->block): ?>
<!-- Block Notes Field -->
<tr>
    <td><?php echo app('translator')->get('models/users.fields.block_notes'); ?></td>
    <td><?php echo e($user->block_notes); ?></td>
</tr>
<?php endif; ?>

<!-- Email Verified At Field -->
<tr>
    <td><?php echo app('translator')->get('models/users.fields.email_verified_at'); ?></td>
    <td><?php echo e($user->email_verified_at); ?></td>
</tr>

<!-- Created At Field -->
<tr>
    <td><?php echo app('translator')->get('crud.created_at'); ?></td>
    <td><?php echo e($user->created_at); ?></td>
</tr>

<!-- Updated At Field -->
<tr>
    <td><?php echo app('translator')->get('crud.updated_at'); ?></td>
    <td><?php echo e($user->updated_at); ?></td>
</tr><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/users/show_fields.blade.php ENDPATH**/ ?>