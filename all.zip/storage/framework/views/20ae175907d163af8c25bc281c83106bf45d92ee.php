<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset(env('APP_FAVICON', 'elite/assets/images/favicon.png'))); ?>">
    <title><?php echo e(__('msg.app_name')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    
    <link href="<?php echo e(asset('elite/assets/node_modules/sweetalert2/dist/sweetalert2.min.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('elite/assets/node_modules/toast-master/css/jquery.toast.css')); ?>">
    <?php echo $__env->yieldPushContent('third_party_stylesheets'); ?>

    <?php if(App::isLocale('ar')): ?>
    <link href="<?php echo e(asset('elite/dist/css/style-rtl.min.css')); ?>" rel="stylesheet">
    <?php else: ?>
    <link href="<?php echo e(asset('elite/dist/css/style.min.css')); ?>" rel="stylesheet">
    <?php endif; ?>

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('page_css'); ?>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="skin-megna fixed-layout">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="loader">
            <div class="loader__figure"></div>
            <p class="loader__label"><?php echo e(__('msg.app_name')); ?></p>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">

        <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h4 class="text-themecolor">
                            <?php if(View::hasSection('page-title')): ?>
                                <?php echo $__env->yieldContent('page-title'); ?>
                            <?php else: ?>
                                <?php echo $__env->yieldContent('title'); ?>
                            <?php endif; ?>
                        </h4>
                    </div>
                    <div class="col-md-7 align-self-center text-right">
                        <div class="d-flex justify-content-end align-items-center">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo app('translator')->get('msg.app_name'); ?></a></li>
                                <?php echo $__env->yieldContent('breadcrumb'); ?>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <?php if(View::hasSection('top-buttons')): ?>
                <div class="row">
                    <div class="col-12">
                        <div class="float-right p-b-10">
                            <?php echo $__env->yieldContent('top-buttons'); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php echo $__env->yieldContent('content'); ?>

            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->

        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->

    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo e(asset('elite/assets/node_modules/jquery/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap popper Core JavaScript -->
    <script src="<?php echo e(asset('elite/assets/node_modules/popper/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('elite/assets/node_modules/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo e(asset('elite/horizontal/dist/js/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <!--Wave Effects -->
    <script src="<?php echo e(asset('elite/horizontal/dist/js/waves.js')); ?>"></script>
    <!--Menu sidebar -->
    <script src="<?php echo e(asset('elite/horizontal/dist/js/sidebarmenu.js')); ?>"></script>
    <script src="<?php echo e(asset('elite/assets/node_modules/sweetalert2/dist/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('elite/assets/node_modules/toast-master/js/jquery.toast.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('third_party_scripts'); ?>

    <!--Custom JavaScript -->
    <script src="<?php echo e(asset('elite/horizontal/dist/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('page_scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>