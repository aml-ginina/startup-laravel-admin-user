<?php $__env->startSection('title', __('crud.show') . ' ' . __('models/users.singular')); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('admin.users.index')); ?>"><?php echo app('translator')->get('models/users.plural'); ?></a></li>
<li class="breadcrumb-item active"><?php echo app('translator')->get('crud.show'); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('top-buttons'); ?>
<a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-info d-none d-lg-block m-l-15"><i class="fa fa-edit"></i> <?php echo app('translator')->get('crud.edit'); ?></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body p-0">
                    <table class="table table-hover">
                        <tbody>
                            <?php echo $__env->make('admin.users.show_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <a class="btn btn-dark" href="<?php echo e(route('admin.users.index')); ?>"><?php echo app('translator')->get('crud.back'); ?></a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/users/show.blade.php ENDPATH**/ ?>