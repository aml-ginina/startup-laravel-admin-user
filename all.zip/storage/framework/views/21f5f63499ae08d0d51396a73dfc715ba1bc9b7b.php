<!-- Name Field -->
<tr>
    <th> <?php echo app('translator')->get('models/admins.fields.name'); ?> </th>
    <td><?php echo e($admin->name); ?></td>
</tr>

<!-- Email Field -->
<tr>
    <th> <?php echo app('translator')->get('models/admins.fields.email'); ?> </th>
    <td><?php echo e($admin->email); ?></td>
</tr>

<!-- Active Field -->
<tr>
    <th> <?php echo app('translator')->get('models/admins.fields.active'); ?> </th>
    <td><?php echo $admin->active_span; ?></td>
</tr>

<!-- Created At Field -->
<tr>
    <td><?php echo app('translator')->get('crud.created_at'); ?></td>
    <td><?php echo e($admin->created_at); ?></td>
</tr>

<!-- Updated At Field -->
<tr>
    <td><?php echo app('translator')->get('crud.updated_at'); ?></td>
    <td><?php echo e($admin->updated_at); ?></td>
</tr><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/admins/show_fields.blade.php ENDPATH**/ ?>