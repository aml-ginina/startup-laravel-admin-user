<!-- ============================================================== -->
<!-- Search -->
<!-- ============================================================== -->
<li class="nav-item">
    <form class="app-search d-none d-md-block d-lg-block">
        <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('msg.search_and_enter'); ?>">
    </form>
</li><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/layouts/header/search.blade.php ENDPATH**/ ?>