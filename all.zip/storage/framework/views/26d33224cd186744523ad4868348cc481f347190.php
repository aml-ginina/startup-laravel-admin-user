<?php $__env->startSection('title', __('auth.reset_password.title')); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::open(['route' => 'password.update', 'type' => 'post', 'class' => 'form-horizontal form-material']); ?>

    <input type="hidden" name="token" value="<?php echo e($token); ?>">
    <h3 class="text-center m-b-20"><?php echo app('translator')->get('auth.reset_password.title'); ?></h3>
    <div class="form-group ">
        <div class="col-xs-12">
            <input type="email"
                name="email"
                value="<?php echo e($email ?? old('email')); ?>"
                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="<?php echo app('translator')->get('auth.email'); ?>">

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="error invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group ">
        <div class="col-xs-12">
            <input type="password"
                name="password"
                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="<?php echo app('translator')->get('auth.password'); ?>">

            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="error invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="form-group ">
        <div class="col-xs-12">
            <input type="password"
                name="password_confirmation"
                class="form-control"
                placeholder="<?php echo app('translator')->get('auth.confirm_password'); ?>">
        </div>
    </div>

    <div class="form-group text-center">
        <div class="col-xs-12 p-b-20">
            <button class="btn btn-primary btn-lg btn-block text-uppercase waves-effect waves-light" type="submit"><?php echo app('translator')->get('auth.reset_password.reset_pwd_btn'); ?></button>
        </div>
    </div>

    <div class="form-group m-b-0">
        <div class="col-sm-12 text-center">
            <a href="<?php echo e(route('login')); ?>" class="text-info m-l-5"><b><?php echo app('translator')->get('auth.sign_in'); ?></b></a>
        </div>
    </div>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>