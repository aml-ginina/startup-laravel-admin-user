<!-- Name Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('name', __('models/users.fields.name').':'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Email Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('email', __('models/users.fields.email').':'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Phone Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('phone', __('models/users.fields.phone').':'); ?>

    <?php echo Form::text('phone', null, ['class' => 'form-control' . ($errors->has('phone') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Password Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('password', __('models/users.fields.password').':'); ?>

    <?php echo Form::password('password', ['class' => 'form-control' . ($errors->has('password') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Image Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('image', __('models/users.fields.image').':'); ?>

    <div class="custom-file">
        <?php echo Form::file('image', ['id' => 'image', 'class' => 'custom-file-input' . ($errors->has('image') ? ' is-invalid' : '')]); ?>

        <label class="custom-file-label" data-browse="<?php echo app('translator')->get('msg.browse'); ?>" for="image">
            <?php if(isset($user)): ?> <?php echo e($user->image); ?> <?php else: ?> <?php echo app('translator')->get('msg.upload_file'); ?> <?php endif; ?>
        </label>
        <?php if($errors->has('image')): ?>
            <span class="invalid-feedback" role="alert">
                <?php echo e($errors->first('image')); ?>

            </span> 
        <?php endif; ?>
    </div>
</div>

<!-- Notes Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('notes', __('models/users.fields.notes').':'); ?>

    <?php echo Form::textarea('notes', null, ['class' => 'form-control' . ($errors->has('notes') ? ' is-invalid' : ''), 'rows' => 5]); ?>

    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Block Field -->
<div class="form-group col-sm-12">
    <div class="custom-control custom-switch">
        <?php echo Form::hidden('block', 0, ['class' => 'form-check-input']); ?>

        <?php echo Form::checkbox('block', '1', null, ['class' => 'custom-control-input', 'id' => 'block']); ?>

        <?php echo Form::label('block', __('models/users.fields.block'), ['class' => 'custom-control-label']); ?>

      </div>
    <?php $__errorArgs = ['block'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Block Notes Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('block_notes', __('models/users.fields.block_notes').':'); ?>

    <?php echo Form::textarea('block_notes', null, ['class' => 'form-control' . ($errors->has('block_notes') ? ' is-invalid' : ''), 'rows' => 5]); ?>

    <?php $__errorArgs = ['block_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<button type="submit" class="btn btn-primary"><?php echo app('translator')->get('crud.save'); ?></button>
<a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-dark"><?php echo app('translator')->get('crud.cancel'); ?></a>

<?php $__env->startPush('page_scripts'); ?>
<script>
    function toggleBlockNotes() {
        if($('#block').is(':checked')) $('#block_notes').closest('div').slideDown(); else $('#block_notes').closest('div').slideUp();
    }
    $('#block').on('change', function() {
        toggleBlockNotes();
    })

    $(function() {
        toggleBlockNotes();
    })
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/users/fields.blade.php ENDPATH**/ ?>