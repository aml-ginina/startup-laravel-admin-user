<div class="tab-pane <?php echo e($active == 'password' ? 'active' : ''); ?>" id="password" role="tabpanel">
    <div class="card-body">
        <?php echo Form::model($provider, ['route' => 'provider.profile.password']); ?>

            <div class="row">
                <!-- Current Password Field -->
                <div class="form-group col-sm-12">
                    <?php echo Form::label('current_password', __('msg.current_password') . ':'); ?>

                    <?php echo Form::password('current_password', ['id' => 'current_password', 'class' => 'form-control' . ($errors->has('current_password') ? ' is-invalid' : '')]); ?>

                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- New Password Field -->
                <div class="form-group col-sm-12">
                    <?php echo Form::label('password', __('msg.new_password') . ':'); ?>

                    <?php echo Form::password('password', ['id' => 'password', 'class' => 'form-control' . ($errors->has('password') ? ' is-invalid' : '')]); ?>

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Password Confirmation Field -->
                <div class="form-group col-sm-12">
                    <?php echo Form::label('password_confirmation', __('msg.confirm_password') . ':'); ?>

                    <?php echo Form::password('password_confirmation', ['id' => 'password_confirmation', 'class' => 'form-control' . ($errors->has('password_confirmation') ? ' is-invalid' : '')]); ?>

                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-12 add_top_20">
                    <input type="submit" value="<?php echo app('translator')->get('msg.submit'); ?>" class="btn btn-primary">
                </div>
            </div>
        <?php echo Form::close(); ?>

    </div>
</div>


<?php /**PATH C:\laragon\www\startup-laravel\resources\views/provider/profile/password_tab.blade.php ENDPATH**/ ?>