<!-- Title Field -->
<tr>
    <th><?php echo app('translator')->get('models/notifications.fields.title'); ?></th>
    <td><i class="<?php echo e($notification->icon); ?>"></i> <?php echo e($notification->title); ?></td>
</tr>

<!-- Text Field -->
<tr>
    <th><?php echo app('translator')->get('models/notifications.fields.text'); ?></th>
    <td><?php echo e($notification->text); ?></td>
</tr>

<!-- Url Field -->
<tr>
    <th><?php echo app('translator')->get('models/notifications.fields.url'); ?></th>
    <td>
        <?php if(!is_null($notification->url)): ?>
        <a class="text-info" href="<?php echo e($notification->url); ?>"><?php echo e($notification->url); ?></a>
        <?php endif; ?>
    </td>
</tr>

<!-- Type Field -->
<tr>
    <th><?php echo app('translator')->get('models/notifications.fields.type'); ?></th>
    <td><span class="label label-<?php echo e($notification->type); ?>"><?php echo e($notification->type); ?></span></td>
</tr>

<!-- Read At Field -->
<tr>
    <td><?php echo app('translator')->get('models/notifications.fields.read_at'); ?></td>
    <td><?php echo e($notification->read_at); ?></td>
</tr>

<!-- Created At Field -->
<tr>
    <td><?php echo app('translator')->get('models/notifications.fields.created_at'); ?></td>
    <td><?php echo e($notification->created_at); ?></td>
</tr><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/notifications/show_fields.blade.php ENDPATH**/ ?>