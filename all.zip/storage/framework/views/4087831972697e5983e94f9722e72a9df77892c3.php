<!-- ============================================================== -->
<!-- Notification -->
<!-- ============================================================== -->
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> 
        <?php echo e(App::getLocale()); ?> <i class="fa fa-angle-down"></i>
        <?php if(($notifs = Auth::guard('admin')->user()->getNotifications(0))->count() > 0): ?>
        <div class="notify warning"> <span class="heartbit"></span> <span class="point"></span> </div>
        <?php endif; ?>
    </a>
    <div class="dropdown-menu dropdown-menu-right animated flipInY">
        <?php $__currentLoopData = $locales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('localization', ['locale' => $locale])); ?>" class="dropdown-item"><?php echo app('translator')->get("locales.{$locale}"); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</li><?php /**PATH C:\laragon\www\startup-laravel\resources\views/provider/layouts/header/locale.blade.php ENDPATH**/ ?>