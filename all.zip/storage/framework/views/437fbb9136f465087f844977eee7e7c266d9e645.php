<?php if(!isset($contact)): ?>
<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', __('models/contacts.fields.name').'*'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', __('models/contacts.fields.email').'*'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Subject Field -->
<div class="form-group">
    <?php echo Form::label('subject', __('models/contacts.fields.subject').'*'); ?>

    <?php echo Form::text('subject', null, ['class' => 'form-control' . ($errors->has('subject') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Message Field -->
<div class="form-group">
    <?php echo Form::label('message', __('models/contacts.fields.message').'*'); ?>

    <?php echo Form::textarea('message', null, ['class' => 'form-control' . ($errors->has('message') ? ' is-invalid' : ''), 'rows' => 5]); ?>

    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<?php endif; ?>

<div class="col-sm-12">
    <div class="form-group">
        <?php echo Form::label('text', __('models/contacts.fields.type').'*', ['class' => 'control-label']); ?>

        <?php $__currentLoopData = [
            'primary' => 'contact', 
            'info' => 'enquiry', 
            'success' => 'suggestion', 
            'warning' => 'help', 
            'danger' => 'complaint'
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="custom-control custom-radio">
            <?php echo Form::radio('type', $type, $type == 'contact' && !isset($contact) ? true : null, ['id' => "type-{$type}", 'class' => 'custom-control-input']); ?>

            <?php echo Form::label("type-{$type}", __("models/contacts.types.{$type}"), ['class' => "custom-control-label text-{$key}"]); ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<!-- Reply Message Field -->
<div class="form-group">
    <?php echo Form::label('reply_message', __('models/contacts.fields.reply_message').':'); ?>

    <?php echo Form::textarea('reply_message', null, ['class' => 'form-control' . ($errors->has('reply_message') ? ' is-invalid' : ''), 'rows' => 5]); ?>

    <?php $__errorArgs = ['reply_message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<button type="submit" class="btn btn-primary"><?php echo app('translator')->get('crud.save'); ?></button>
<a href="<?php echo e(route('admin.contacts.index')); ?>" class="btn btn-dark"><?php echo app('translator')->get('crud.cancel'); ?></a><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/contacts/fields.blade.php ENDPATH**/ ?>