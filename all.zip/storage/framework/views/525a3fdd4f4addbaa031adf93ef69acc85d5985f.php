<div class="table-responsive m-t-30 m-b-20">
    <table id="notifications-table" class="table display table-bordered table-striped no-wrap">
        <thead>
            <tr>
                <th><?php echo app('translator')->get('models/notifications.singular'); ?></th>
                <th><?php echo app('translator')->get('models/notifications.fields.read_at'); ?></th>
                <th><?php echo app('translator')->get('crud.action'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('provider.notifications.show', $notification->id)); ?>" class="list-group-item list-group-item-action flex-column align-items-start">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1">
                                <?php if(!is_null($notification->icon)): ?> <i class="<?php echo e($notification->icon); ?> text-<?php echo e($notification->type); ?>"></i> <?php endif; ?>
                                <?php echo e($notification->title); ?>

                            </h5>
                            <small><?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($notification->created_at))->diffForHumans()); ?></small>
                        </div>
                        <p class="mb-1" 
                            style="width: 100%; white-space: normal;">
                            <?php echo substr($notification->text, 0, 80) . (Str::length($notification->text) > 80 ? ' ..' : ''); ?>

                        </p>
                    </a>
                </td>
                <td>
                    <?php if(!is_null($notification->read_at)): ?>
                    <span class="badge badge-success"><?php echo app('translator')->get('models/notifications.read'); ?></span>
                    <?php else: ?>
                    <span class="badge badge-danger"><?php echo app('translator')->get('models/notifications.unread'); ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php echo Form::open(['route' => ['provider.notifications.update', $notification->id], 'method' => 'patch', 'class' => 'd-inline']); ?>

                        <?php echo Form::button('<i class="ti-pencil"></i>', ['type' => 'submit', 'class' => 'btn btn-info btn-sm btn-confirm', 'data-title' => __('msg.confirm'), 'data-text' => $notification->read_at ? __('msg.mark_as_unread') : __('msg.mark_as_read')]); ?>

                    <?php echo Form::close(); ?>

                    <?php echo Form::open(['route' => ['provider.notifications.destroy', $notification->id], 'method' => 'delete', 'class' => 'd-inline']); ?>

                        <?php echo Form::button('<i class="ti-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-sm btn-confirm']); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->startPush('third_party_stylesheets'); ?>
<link rel="stylesheet" type="text/css"
    href="<?php echo e(asset('elite/assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css')); ?>">
<link rel="stylesheet" type="text/css"
    href="<?php echo e(asset('elite/assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('third_party_scripts'); ?>
<!-- This is data table -->
<script src="<?php echo e(asset('elite/assets/node_modules/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('elite/assets/node_modules/datatables.net-bs4/js/dataTables.responsive.min.js')); ?>"></script>
<script src="https://cdn.datatables.net/select/1.3.4/js/dataTables.select.min.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('page_scripts'); ?>
<script>
    $(function () {
        // responsive table
        $('#notifications-table').DataTable({
            responsive: true
        });
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/provider/notifications/table.blade.php ENDPATH**/ ?>