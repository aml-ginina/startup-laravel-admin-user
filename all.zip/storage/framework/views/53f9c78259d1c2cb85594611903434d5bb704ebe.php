<!-- ============================================================== -->
<!-- Logo -->
<!-- ============================================================== -->
<div class="navbar-header">
    <a class="navbar-brand" href="<?php echo e(route('admin.home')); ?>">
        <!-- Logo icon --><b>
            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
            <!-- Dark Logo icon -->
            <img src="<?php echo e(asset('elite/assets/images/logo-icon.png')); ?>" alt="<?php echo app('translator')->get('msg.app_name'); ?>" class="dark-logo" />
            <!-- Light Logo icon -->
            <img src="<?php echo e(asset('elite/assets/images/logo-light-icon.png')); ?>" alt="<?php echo app('translator')->get('msg.app_name'); ?>" class="light-logo" />
        </b>
        <!--End Logo icon -->
        <!-- Logo text --><span class="hidden-sm-down">
            <!-- dark Logo text -->
            <img src="<?php echo e(asset('elite/assets/images/logo-text.png')); ?>" alt="<?php echo app('translator')->get('msg.app_name'); ?>" class="dark-logo" />
            <!-- Light Logo text -->    
            <img src="<?php echo e(asset('elite/assets/images/logo-light-text.png')); ?>" class="light-logo" alt="<?php echo app('translator')->get('msg.app_name'); ?>" /></span> </a>
</div>
<!-- ============================================================== -->
<!-- End Logo -->
<!-- ============================================================== --><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/layouts/header/logo.blade.php ENDPATH**/ ?>