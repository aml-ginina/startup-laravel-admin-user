<!-- Name Field -->
<tr>
    <th><?php echo app('translator')->get('models/contacts.fields.name'); ?></th>
    <td><?php echo e($contact->name); ?></td>
</tr>

<!-- Email Field -->
<tr>
    <th><?php echo app('translator')->get('models/contacts.fields.email'); ?></th>
    <td><?php echo e($contact->email); ?></td>
</tr>

<!-- Type Field -->
<tr>
    <th><?php echo app('translator')->get('models/contacts.fields.type'); ?></th>
    <td><?php echo e($contact->type); ?></td>
</tr>

<!-- Subject Field -->
<tr>
    <th><?php echo app('translator')->get('models/contacts.fields.subject'); ?></th>
    <td><?php echo e($contact->subject); ?></td>
</tr>

<!-- Message Field -->
<tr>
    <th><?php echo app('translator')->get('models/contacts.fields.message'); ?></th>
    <td><?php echo e($contact->message); ?></td>
</tr>

<!-- Read At Field -->
<tr>
    <th><?php echo app('translator')->get('models/contacts.fields.read_at'); ?></th>
    <td><?php echo e($contact->read_at); ?></td>
</tr>

<!-- Reply Message Field -->
<tr>
    <th><?php echo app('translator')->get('models/contacts.fields.reply_message'); ?></th>
    <td><?php echo e($contact->reply_message); ?></td>
</tr>

<!-- Created At Field -->
<tr>
    <th><?php echo app('translator')->get('models/contacts.fields.created_at'); ?></th>
    <td><?php echo e($contact->created_at); ?></td>
</tr>

<!-- Updated At Field -->
<tr>
    <th><?php echo app('translator')->get('models/contacts.fields.updated_at'); ?></th>
    <td><?php echo e($contact->updated_at); ?></td>
</tr>

<?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/contacts/show_fields.blade.php ENDPATH**/ ?>