<?php $__env->startSection('title', __('auth.login.title')); ?>

<?php $__env->startSection('content'); ?>
<?php echo Form::open(['route' => 'login', 'type' => 'post', 'class' => 'form-horizontal form-material', 'id' => 'loginform']); ?>

    <h3 class="text-center m-b-20"><?php echo app('translator')->get('auth.login.title'); ?></h3>
    <div class="form-group ">
        <div class="col-xs-12">
            <input type="email"
                name="email"
                value="<?php echo e(old('email')); ?>"
                placeholder="<?php echo app('translator')->get('auth.email'); ?>"
                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="error invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group ">
        <div class="col-xs-12">
            <input type="password"
                name="password"
                placeholder="<?php echo app('translator')->get('auth.password'); ?>"
                class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="error invalid-feedback"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group row">
        <div class="col-md-12">
            <div class="d-flex no-block align-items-center">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="remember" name="remember">
                    <label class="custom-control-label" for="remember"><?php echo app('translator')->get('auth.login.remember_me'); ?></label>
                </div> 
                <div class="ml-auto">
                    <a href="<?php echo e(route('password.request')); ?>" class="text-muted"><i class="fas fa-lock m-r-5"></i> <?php echo app('translator')->get('auth.login.forgot_password'); ?></a> 
                </div>
            </div>
        </div>
    </div>

    <div class="form-group text-center">
        <div class="col-xs-12 p-b-20">
            <button class="btn btn-block btn-lg btn-info btn-rounded" type="submit"><?php echo app('translator')->get('auth.sign_in'); ?></button>
        </div>
    </div>

    <div class="form-group m-b-0">
        <div class="col-sm-12 text-center">
            <?php echo app('translator')->get('auth.login.register_membership'); ?> <a href="<?php echo e(route('register')); ?>" class="text-info m-l-5"><b><?php echo app('translator')->get('auth.sign_up'); ?></b></a>
        </div>
    </div>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>