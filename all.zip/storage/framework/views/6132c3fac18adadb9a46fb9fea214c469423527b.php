<div class="tab-pane <?php echo e($active == 'settings' ? 'active' : ''); ?>" id="settings" role="tabpanel">
    <div class="card-body">
        <?php echo Form::model($admin, ['route' => 'admin.profile.settings', 'files' => 'on']); ?>

            <?php echo Form::hidden('admin', $admin->id); ?>

            <div class="row">
                <div class="form-group col-sm-12">
                    <label><?php echo app('translator')->get('msg.name'); ?> *</label>
                    <?php echo Form::text('name', null, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : '')]); ?>

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-sm-12">
                    <label><?php echo app('translator')->get('msg.email'); ?> *</label>
                    <?php echo Form::email('email', null, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : '')]); ?>

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-sm-12 add_top_20">
                    <input type="submit" value="<?php echo app('translator')->get('msg.submit'); ?>" class="btn btn-primary">
                </div>
            </div>
        <?php echo Form::close(); ?>

    </div>
</div><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/profile/settings_tab.blade.php ENDPATH**/ ?>