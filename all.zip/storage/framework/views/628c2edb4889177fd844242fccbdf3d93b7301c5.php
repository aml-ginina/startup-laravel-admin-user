<!-- Name Field -->
<div class="form-group">
    <?php echo Form::label('name', __('models/providers.fields.name').':'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', __('models/providers.fields.email').':'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Phone Field -->
<div class="form-group">
    <?php echo Form::label('phone', __('models/providers.fields.phone').':'); ?>

    <?php echo Form::text('phone', null, ['class' => 'form-control' . ($errors->has('phone') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Password Field -->
<div class="form-group">
    <?php echo Form::label('password', __('models/providers.fields.password').':'); ?>

    <?php echo Form::password('password', ['class' => 'form-control' . ($errors->has('password') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Image Field -->
<div class="form-group">
    <?php echo Form::label('image', __('models/providers.fields.image')); ?>

    <div class="input-group">
        <div class="custom-file mb-3">
            <?php echo Form::file('image', ['class' => 'custom-file-input' . ($errors->has('image') ? ' is-invalid' : '')]); ?>

            <?php echo Form::label('image', isset($$MODEL_NAME) ? $Provider->image : __('msg.updoad_file'), ['class' => 'custom-file-label form-control', 'data-browse' => __('msg.browse')]); ?>

        </div>
    </div>
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<!-- Notes Field -->
<div class="form-group">
    <?php echo Form::label('notes', __('models/providers.fields.notes').':'); ?>

    <?php echo Form::textarea('notes', null, ['class' => 'form-control' . ($errors->has('notes') ? ' is-invalid' : ''), 'rows' => 5]); ?>

    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Approve Field -->
<div class="form-group col-sm-12">
    <div class="custom-control custom-switch">
        <?php echo Form::hidden('approve', 0, ['class' => 'form-check-input']); ?>

        <?php echo Form::checkbox('approve', '1', null, ['class' => 'custom-control-input', 'id' => 'approve']); ?>

        <?php echo Form::label('approve', __('models/providers.fields.approve'), ['class' => 'custom-control-label']); ?>

      </div>
    <?php $__errorArgs = ['approve'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Block Field -->
<div class="form-group col-sm-12">
    <div class="custom-control custom-switch">
        <?php echo Form::hidden('block', 0, ['class' => 'form-check-input']); ?>

        <?php echo Form::checkbox('block', '1', null, ['class' => 'custom-control-input', 'id' => 'block']); ?>

        <?php echo Form::label('block', __('models/providers.fields.block'), ['class' => 'custom-control-label']); ?>

      </div>
    <?php $__errorArgs = ['block'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Block Notes Field -->
<div class="form-group">
    <?php echo Form::label('block_notes', __('models/providers.fields.block_notes').':'); ?>

    <?php echo Form::textarea('block_notes', null, ['class' => 'form-control' . ($errors->has('block_notes') ? ' is-invalid' : ''), 'rows' => 5]); ?>

    <?php $__errorArgs = ['block_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<button type="submit" class="btn btn-primary"><?php echo app('translator')->get('crud.save'); ?></button>
<a href="<?php echo e(route('admin.providers.index')); ?>" class="btn btn-dark"><?php echo app('translator')->get('crud.cancel'); ?></a>

<?php $__env->startPush('page_scripts'); ?>
<script>
    function toggleBlockNotes() {
        if($('#block').is(':checked')) $('#block_notes').closest('div').slideDown(); else $('#block_notes').closest('div').slideUp();
    }
    $('#block').on('change', function() {
        toggleBlockNotes();
    })

    $(function() {
        toggleBlockNotes();
    })
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/providers/fields.blade.php ENDPATH**/ ?>