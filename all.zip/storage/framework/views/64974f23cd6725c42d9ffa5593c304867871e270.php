<!-- Title Field -->
<div class="form-group">
    <?php echo Form::label('title', __('models/notifications.fields.title').'*'); ?>

    <?php echo Form::text('title', null, ['class' => 'form-control' . ($errors->has('title') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Text Field -->
<div class="form-group">
    <?php echo Form::label('text', __('models/notifications.fields.text').'*'); ?>

    <?php echo Form::textarea('text', null, ['class' => 'form-control' . ($errors->has('text') ? ' is-invalid' : ''), 'rows' => 5]); ?>

    <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="col-sm-12">
    <div class="form-group">
        <?php echo Form::label('text', __('models/notifications.fields.type').'*', ['class' => 'control-label']); ?>

        <?php $__currentLoopData = ['primary', 'info', 'success', 'warning', 'danger']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="custom-control custom-radio">
            <?php echo Form::radio('type', $type, $type == 'primary' && !isset($notification) ? true : null, ['id' => "type-{$type}", 'class' => 'custom-control-input']); ?>

            <?php echo Form::label("type-{$type}", __("models/notifications.types.{$type}"), ['class' => "custom-control-label text-{$type}"]); ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="form-group">
    <?php echo Form::label('to', __('models/notifications.fields.to').'*'); ?>

    <?php echo Form::select('to', [
        'admin' => __('models/admins.singular'),
        'user' => __('models/users.singular'),
        'provider' => __('models/providers.singular')
        ], null, ['class' => 'form-control selectpicker' . ($errors->has('to') ? ' is-invalid' : '')]); ?>


    <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group to-div" id="admin-div">
    <?php echo Form::label('admin_id', __('models/notifications.fields.admin_id').':'); ?>

    <div class="custom-control custom-checkbox d-inline-block float-right">
        <?php echo Form::checkbox('all_admins', '1', null, ['class' => 'custom-control-input check-all', 'id' => 'all-admins']); ?>

        <?php echo Form::label('all-admins', __('models/notifications.to.all_admins'), ['class' => 'custom-control-label']); ?>

    </div>
    <?php echo Form::select('admins[]', App\Models\Admin::where('id', '!=', Auth::guard('admin')->user()->id)->pluck('name', 'id'), null, ['class' => 'form-control custom-select select2' . ($errors->has('admins') ? ' is-invalid' : ''), 'multiple' => true, 'id' => 'admin_id']); ?>

    <?php $__errorArgs = ['admins'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group to-div" id="user-div">
    <?php echo Form::label('user_id', __('models/notifications.fields.user_id').':'); ?>

    <div class="custom-control custom-checkbox d-inline-block float-right">
        <?php echo Form::checkbox('all_users', '1', null, ['class' => 'custom-control-input check-all', 'id' => 'all-users']); ?>

        <?php echo Form::label('all-users', __('models/notifications.to.all_users'), ['class' => 'custom-control-label']); ?>

    </div>
    <?php echo Form::select('users[]', App\Models\User::pluck('name', 'id'), null, ['class' => 'form-control custom-select select2' . ($errors->has('users') ? ' is-invalid' : ''), 'multiple' => true, 'id' => 'user_id']); ?>

    <?php $__errorArgs = ['users'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group to-div" id="provider-div">
    <?php echo Form::label('provider_id', __('models/notifications.fields.provider_id').':'); ?>

    <div class="custom-control custom-checkbox d-inline-block float-right">
        <?php echo Form::checkbox('all_providers', '1', null, ['class' => 'custom-control-input check-all', 'id' => 'all-providers']); ?>

        <?php echo Form::label('all-providers', __('models/notifications.to.all_providers'), ['class' => 'custom-control-label']); ?>

    </div>
    <?php echo Form::select('providers[]', App\Models\Provider::pluck('name', 'id'), null, ['class' => 'form-control custom-select select2' . ($errors->has('providers') ? ' is-invalid' : ''), 'multiple' => true, 'id' => 'provider_id']); ?>

    <?php $__errorArgs = ['providers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Url Field -->
<div class="form-group">
    <?php echo Form::label('url', __('models/notifications.fields.url').':'); ?>

    <?php echo Form::text('url', null, ['class' => 'form-control' . ($errors->has('url') ? ' is-invalid' : '')]); ?>

    <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<!-- Icon Field -->
<div class="form-group">
    <?php echo Form::label('icon', __('models/notifications.fields.icon').':'); ?>

    <?php echo Form::text('icon', null, ['class' => 'form-control' . ($errors->has('icon') ? ' is-invalid' : '')]); ?>

    <small id="iconlHelp" class="form-text text-muted">ex: fa fa-user / icon-heart / ti-settings ...</small>
    <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback"> <?php echo e($message); ?> </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<button type="submit" class="btn btn-primary"><?php echo app('translator')->get('crud.save'); ?></button>
<a href="<?php echo e(route('admin.notifications.index')); ?>" class="btn btn-dark"><?php echo app('translator')->get('crud.cancel'); ?></a>

<?php $__env->startPush('third_party_stylesheets'); ?>
    <!-- Select2 plugins css -->
    <link href="<?php echo e(asset('elite/assets/node_modules/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('elite/assets/node_modules/bootstrap-select/bootstrap-select.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('third_party_scripts'); ?>
    <!-- Select2 Plugin JavaScript -->
    <script src="<?php echo e(asset('elite/assets/node_modules/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('elite/assets/node_modules/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('page_scripts'); ?>
    <script type="text/javascript">
        $('.select2').select2();
        $('.selectpicker').selectpicker();

        $(".check-all").on('change', function() {
            let select = $(this).closest('div').parent().find('select');
            if($(this).is(':checked')) {
                select.select2('destroy').find('option').prop('selected', 'selected').end().select2();
            } else {
                select.select2('destroy').find('option').prop('selected', false).end().select2();
            }
        });

        $('#to').on('change', function() {
            adminOrUser();
        })

        $(function() {
            adminOrUser();
        })

        function adminOrUser() {
            $('.to-div').hide();
            $(`#${$('#to').val()}-div`).slideDown();
        }
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/notifications/fields.blade.php ENDPATH**/ ?>