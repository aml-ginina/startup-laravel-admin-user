<!-- ============================================================== -->
<!-- User Profile -->
<!-- ============================================================== -->
<li class="nav-item dropdown u-pro">
    <a class="nav-link dropdown-toggle waves-effect waves-dark profile-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <img src="<?php echo e(asset('images/providers/'.Auth::guard('provider')->user()->image)); ?>" alt="" class=""> 
        <span class="hidden-md-down"><?php echo e(Auth::guard('provider')->user()->name); ?> &nbsp;<i class="fa fa-angle-down"></i></span> </a>
    <div class="dropdown-menu dropdown-menu-right animated flipInY">
        <!-- text-->
        <a href="<?php echo e(route('provider.profile.index')); ?>" class="dropdown-item"><i class="ti-user"></i> <?php echo app('translator')->get('msg.profile'); ?></a>

        <div class="dropdown-divider"></div>
        <!-- text-->
        <a href="<?php echo e(route('provider.profile.index', ['active' => 'settings'])); ?>" class="dropdown-item"><i class="ti-settings"></i> <?php echo app('translator')->get('msg.settings'); ?></a>
        <!-- text-->
        <div class="dropdown-divider"></div>
        <!-- text-->
        <a href="#" class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="fa fa-power-off"></i> <?php echo app('translator')->get('auth.sign_out'); ?></a>
        <!-- text-->
        <form id="logout-form" action="<?php echo e(route('provider.logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </div>
</li>
<!-- ============================================================== -->
<!-- End User Profile -->
<!-- ============================================================== -->
<?php /**PATH C:\laragon\www\startup-laravel\resources\views/provider/layouts/header/user_dropdown.blade.php ENDPATH**/ ?>