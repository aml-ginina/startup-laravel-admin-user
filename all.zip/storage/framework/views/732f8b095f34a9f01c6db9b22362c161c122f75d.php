<!-- Name Field -->
<tr>
    <th><?php echo app('translator')->get('models/providers.fields.name'); ?></th>
    <td><?php echo e($provider->name); ?></td>
</tr>

<!-- Email Field -->
<tr>
    <th><?php echo app('translator')->get('models/providers.fields.email'); ?></th>
    <td><?php echo e($provider->email); ?></td>
</tr>

<!-- Phone Field -->
<tr>
    <th><?php echo app('translator')->get('models/providers.fields.phone'); ?></th>
    <td><?php echo e($provider->phone); ?></td>
</tr>

<!-- Image Field -->
<tr>
    <th><?php echo app('translator')->get('models/providers.fields.image'); ?></th>
    <td><img src="<?php echo e(asset('images/providers/'.$provider->image)); ?>" /></td>
</tr>

<!-- Notes Field -->
<tr>
    <th><?php echo app('translator')->get('models/providers.fields.notes'); ?></th>
    <td><?php echo e($provider->notes); ?></td>
</tr>

<!-- Block Field -->
<tr>
    <th><?php echo app('translator')->get('models/providers.fields.block'); ?></th>
    <td><?php echo $provider->block_span; ?></td>
</tr>

<!-- Block Notes Field -->
<tr>
    <th><?php echo app('translator')->get('models/providers.fields.block_notes'); ?></th>
    <td><?php echo e($provider->block_notes); ?></td>
</tr>

<!-- Approve Field -->
<tr>
    <th><?php echo app('translator')->get('models/providers.fields.approve'); ?></th>
    <td><?php echo $provider->approve_span; ?></td>
</tr>

<!-- Email Verified At Field -->
<tr>
    <td><?php echo app('translator')->get('models/providers.fields.email_verified_at'); ?></td>
    <td><?php echo e($provider->email_verified_at); ?></td>
</tr>

<!-- Phone Verified At Field -->
<tr>
    <td><?php echo app('translator')->get('models/providers.fields.phone_verified_at'); ?></td>
    <td><?php echo e($provider->phone_verified_at); ?></td>
</tr>

<!-- Created At Field -->
<tr>
    <td><?php echo app('translator')->get('models/providers.fields.created_at'); ?></td>
    <td><?php echo e($provider->created_at); ?></td>
</tr>

<!-- Updated At Field -->
<tr>
    <td><?php echo app('translator')->get('models/providers.fields.updated_at'); ?></td>
    <td><?php echo e($provider->updated_at); ?></td>
</tr>

<?php /**PATH C:\laragon\www\startup-laravel\resources\views/admin/providers/show_fields.blade.php ENDPATH**/ ?>